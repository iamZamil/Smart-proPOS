<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INVOICE</title>
</head>
<body>
    <h2>INVOICE</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>test</td>
                <td>150</td>
                <td>5</td>
                <td>750</td>
            </tr>
        </tbody>
        <tr>
            <th colspan="4" class="my_tab">GST (18%)</th>
            <th>450</th>
        </tr>
        <tr>
            <th colspan="4" class="my_tab">Grand Total</th>
            <th>1200</th>
        </tr>
    </table>
</body>
</html>
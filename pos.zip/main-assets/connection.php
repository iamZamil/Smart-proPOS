<?php 
// $con = mysqli_connect('localhost', 'root', '','pos');
$con = mysqli_connect('localhost', 'u693327094_husnain01', 'Phoolshah@12345','u693327094_pos');
if(!$con){
    echo mysqli_connect_error();
}else{
    // echo "connected";
}
?>